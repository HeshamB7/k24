package com.k24.carplay

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class AppEntry(val pkg: String, val cls: String, val label: String, val icon: Drawable) {
        fun key() = "$pkg/$cls"
    }

    private val apps = ArrayList<AppEntry>()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var grid: GridView
    private lateinit var status: TextView
    private lateinit var adapter: AppAdapter

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            loadApps()
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            updateStatus()
            ui.postDelayed(this, 15000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("k24", MODE_PRIVATE)
        grid = findViewById(R.id.grid)
        status = findViewById(R.id.status)
        adapter = AppAdapter()
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> launch(apps[pos]) }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            togglePin(apps[pos])
            true
        }

        val navMaps = findViewById<TextView>(R.id.navMaps)
        val navZlink = findViewById<TextView>(R.id.navZlink)
        navIcon(navMaps, MAPS)
        navIcon(navZlink, ZLINK)
        findViewById<View>(R.id.navHome).setOnClickListener { grid.setSelection(0) }
        navMaps.setOnClickListener { openPackage(MAPS, "Google Maps") }
        navZlink.setOnClickListener { openPackage(ZLINK, "ZLINK") }
        findViewById<View>(R.id.navSettings).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                toast("Cannot open Settings")
            }
        }
        findViewById<View>(R.id.navFactory).setOnClickListener {
            try {
                startActivity(
                    Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_HOME)
                        .setComponent(ComponentName("com.android.launcher", "com.android.launcher2.Launcher"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
                toast("Factory launcher not found")
            }
        }

        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addAction(Intent.ACTION_PACKAGE_CHANGED)
        f.addDataScheme("package")
        registerReceiver(pkgReceiver, f)

        loadApps()
    }

    override fun onResume() {
        super.onResume()
        ui.removeCallbacks(tick)
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        grid.setSelection(0)
    }

    // A launcher must not close itself on Back.
    override fun onBackPressed() {}

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val pinned = (prefs.getString("pinned", "") ?: "").split("|").filter { it.isNotEmpty() }
            val list = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppEntry(
                        it.activityInfo.packageName,
                        it.activityInfo.name,
                        it.loadLabel(pm).toString(),
                        it.loadIcon(pm)
                    )
                }
                .sortedWith(compareBy<AppEntry>({
                    val i = pinned.indexOf(it.key())
                    if (i < 0) Int.MAX_VALUE else i
                }, { it.label.lowercase() }))
            ui.post {
                apps.clear()
                apps.addAll(list)
                adapter.notifyDataSetChanged()
                updateStatus()
            }
        }.start()
    }

    private fun launch(e: AppEntry) {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(ComponentName(e.pkg, e.cls))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        } catch (ex: Exception) {
            toast("Cannot open ${e.label}")
        }
    }

    private fun togglePin(e: AppEntry) {
        val list = (prefs.getString("pinned", "") ?: "").split("|").filter { it.isNotEmpty() }.toMutableList()
        val removed = list.remove(e.key())
        if (!removed) list.add(0, e.key())
        prefs.edit().putString("pinned", list.joinToString("|")).apply()
        toast(if (removed) "Unpinned ${e.label}" else "Pinned ${e.label}")
        loadApps()
    }

    private fun openPackage(pkg: String, name: String) {
        try {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i == null) {
                toast("$name is not installed")
                return
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Cannot open $name")
        }
    }

    private fun navIcon(tv: TextView, pkg: String) {
        try {
            val d = packageManager.getApplicationIcon(pkg)
            val s = (56 * resources.displayMetrics.density).toInt()
            d.setBounds(0, 0, s, s)
            tv.setCompoundDrawables(null, d, null, null)
            tv.compoundDrawablePadding = 6
        } catch (e: Exception) {
        }
    }

    private fun updateStatus() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        val caps = if (n == null) null else cm.getNetworkCapabilities(n)
        val net = when {
            caps == null -> "No network"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi connected"
            else -> "Connected"
        }
        status.text = "$net   |   ${apps.size} apps"
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(position: Int): Any = apps[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView
                ?: LayoutInflater.from(this@MainActivity).inflate(R.layout.item_app, parent, false)
            val e = apps[position]
            v.findViewById<ImageView>(R.id.icon).setImageDrawable(e.icon)
            v.findViewById<TextView>(R.id.label).text = e.label
            return v
        }
    }

    companion object {
        const val MAPS = "com.google.android.apps.maps"
        const val ZLINK = "com.zjinnova.zlink"
    }
}
