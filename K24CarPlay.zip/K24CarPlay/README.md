# K24 CarPlay launcher (NWD K2401, Android 10, 32-bit)

Status: source only. NOT built, NOT tested on the device (the authoring sandbox had no access to Google/Gradle servers).
Only the XML files were checked for well-formedness. The first build may need small fixes.

## Build
- Android Studio (JDK 17): open this folder, sync, Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
  If sync says the Gradle wrapper jar is missing, run `gradle wrapper --gradle-version 8.2.1` in this folder, or point Studio to a local Gradle 8.2.x.
- No PC: upload the folder to a GitHub repo; Actions > "Build debug APK" produces the APK as an artifact (untested workflow).

## Install (root shell on the unit, or `adb shell` from a PC)
    pm install -r /sdcard/Download/app-debug.apk
    am start -n com.k24.carplay/.MainActivity
Test it first as a normal app. Only then make it HOME:
    cmd package set-home-activity com.k24.carplay/.MainActivity
    cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME

## Rollback
    cmd package set-home-activity com.android.launcher/com.android.launcher2.Launcher
    pm uninstall com.k24.carplay
The sidebar button "Factory Home" opens the original launcher. Backup of the original APKs: /sdcard/k24_backup/ (copy it off the unit).
Never uninstall or disable com.android.launcher: it hosts steering-wheel learning, screen-off, lock screen and services.

## Status
Implemented (untested): landscape launcher, dynamic discovery of every LAUNCHER activity (sideloaded included), alphabetical grid,
long-press = pin/unpin to front, clock/date, Wi-Fi status, Maps / ZLINK / Settings / Factory Home shortcuts, live refresh on install/uninstall.
Partial: dashboard (clock/date/status only).
Not implemented: media controls (needs notification-listener access), rear camera (NWD camera path not identified; no change to backcar or reverse behavior),
hotspot control (Android already auto-joins saved networks; test it), overlay removal (not a launcher feature).

## Test checklist
1. App opens in landscape, nothing hidden under the 48 px status bar.
2. All installed apps appear, including sideloaded ones; tap opens each.
3. Maps, ZLINK, Settings, Factory Home buttons work.
4. After set-home-activity: Home key, steering-wheel keys, BT call/music, radio, AUX, USB video, GPS still work.
5. Reverse gear: factory camera appears exactly as before and returns to the launcher afterwards.
6. Reboot: the unit boots into the launcher; Wi-Fi rejoins the iPhone hotspot.
7. Install/uninstall an APK: the grid updates without a restart.
8. Watch temperature and meminfo after 30 min of use.
